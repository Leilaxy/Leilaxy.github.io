# wcc-portfolio
 
